require "application_system_test_case"

class ProfessorsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit professors_url
  #
  #   assert_selector "h1", text: "Professor"
  # end
end
