require "application_system_test_case"

class MessagesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit messages_url
  #
  #   assert_selector "h1", text: "Message"
  # end
end
