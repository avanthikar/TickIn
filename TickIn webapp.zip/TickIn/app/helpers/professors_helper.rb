module ProfessorsHelper
end
