class Professor < ApplicationRecord
	has_many :sections
end
