class Student < ApplicationRecord
	has_many :checkins
end
