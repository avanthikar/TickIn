class Checkin < ApplicationRecord
	belongs_to :student
end
