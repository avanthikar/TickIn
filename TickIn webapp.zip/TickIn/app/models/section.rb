class Section < ApplicationRecord
	belongs_to :professor
end
